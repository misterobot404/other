#include <iostream>

using namespace std;

void task1();
void task2();
void task3();

void main() {
    // setlocale(LC_ALL, "Russian");

    while (true)
    {
        cout << "**** Лабораторная работа №2 ****" << endl;
        cout << "Введите номер задания (1, 2, 3): ";
        int task_number = NULL;
        cin >> task_number;
        cout << endl;

        switch (task_number)
        {
        case 1:
            task1();
            break;
        case 2:
            task2();
            break;
        case 3:
            task3();
            break;
        default:
            break;
        }

        cout << endl;
    }

}

/*
Билеты на дневные спектакли для детей до 7 лет стоят 50 руб., а для
взрослых –100 руб. В какую сумму обойдется выход в театр всей семьи, при
этом учесть, что если сумма превышает 2000 руб., то предоставляется 10%
скидка.
*/
void task1() {
    cout << "Задание 1" << endl;

    double count_of_parent = 0, count_of_child = 0;

    // Проверка на ввод недопустимых символов (ожидаются только целые числа) и ввода меньше 0. Требуется по условию задачи
    while (true)
    {
        cout << "Введите количество взрослых (старше 7 лет): ";
        cin >> count_of_parent;
        
        if (cin.fail()) {
            cin.clear();
            cin.ignore();
            cout << "Ошибка валидации. Введите число!" << endl;
            continue;
        }

        if (count_of_parent < 0) {
            cout << "Ошибка валидации. Введите число не менее 0!" << endl;
            continue;
        }

        if (count_of_parent != (int)count_of_parent) {
            cout << "Ошибка валидации. Введите только целое число!" << endl;
            continue;
        }
        
        break;
    }
    
    // Проверка на ввод недопустимых символов (ожидаются только целые числа) и ввода меньше 0. Требуется по условию задачи
    while (true)
    {
        cout << "Введите количество детей (до 7 лет): ";
        cin >> count_of_child;

        if (cin.fail()) {
            cin.clear();
            cin.ignore();
            cout << "Ошибка валидации. Введите число!" << endl;
            continue;
        }

        if (count_of_child < 0) {
            cout << "Ошибка валидации. Введите число не менее 0!" << endl;
            continue;
        }

        if (count_of_child != (int)count_of_child) {
            cout << "Ошибка валидации. Введите только целое число!" << endl;
            continue;
        }

        break;
    }

    // Общая сумма
    double sum = count_of_parent * 100 + count_of_child * 50;
    
    // С возможной скидкой
    if (sum > 2000)
    {
        sum *= 0.9;
        cout << "Была применена скидка 10%" << endl;
    }

    cout << "Общая сумма для входа в театр: " << sum << endl;
}

/*
Заданы три числа: a, b, c. Определить, могут ли они быть сторонами
треугольника, и если да, то определить его тип: равносторонний,
равнобедренный, разносторонний.
Замечание. Условия существования треугольника: a≤b+c; b≤a+c; c≤a+b.
Нельзя исключать экстремальных случаев, когда одна (или несколько) сторон
равны нулю либо когда одно из неравенств переходит в равенство (треугольник
нулевой площади).
*/
void task2() {
    cout << "Задание 2" << endl;

    double a = 0, b = 0, c = 0;

    cout << "Введите длину стороны a: ";
    cin >> a;

    cout << "Введите длину стороны b: ";
    cin >> b;

    cout << "Введите длину стороны c: ";
    cin >> c;

    if (!((a <= b + c) && (b <= a + c) && (c <= a + b))) {
        cout << "Такой треугольник не проходит условия существования";
        return;
    }

    if (a == b && b == c) {
        cout << "Треугольник равносторонний" << endl;
    }
    else if (a == b || a == c || b == c) {
        cout << "Треугольник равнобедренный" << endl;
    }
    else {
        cout << "Треугольник разносторонний" << endl;
    }
        
}

/*
Дана ограниченная область и точка A(x, y). Написать программу, которая
проверяет, попадает ли точка с координатами пользователя в заданную область.
Область - круг в круге
*/
void task3() {
    cout << "Задание 3" << endl;

    double r_inside = 0, r_outside = 0, point_x = 0, point_y = 0;

    cout << "Введите внутренний радиус: ";
    cin >> r_inside;

    cout << "Введите внешний радиус: ";
    cin >> r_outside;

    cout << "Введите координаты точки" << endl;
    cout << "Введите x: ";
    cin >> point_x;
    cout << "Введите y: ";
    cin >> point_y;

    if (((point_x * point_x + point_y * point_y) < (r_inside * r_inside)) || ((point_x * point_x + point_y * point_y) > (r_outside * r_outside)))
    {
        cout << "Точка не попадает между внутренним и внешним радиусом" << endl;
    }
    else
    {
        cout << "Точка попадает между внутренним и внешним радиусом" << endl;
    }
}