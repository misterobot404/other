#include <iostream>

using namespace std;

void task1();
void task2();
void task3();
void task4();
void task5();

double fact(int);

void main() {
    // setlocale(LC_ALL, "Russian");

    while (true)
    {
        cout << "**** Лабораторная работа №3 ****" << endl;
        cout << "Введите номер задания (1, 2, 3, 4, 5): ";
        int task_number = NULL;
        cin >> task_number;
        cout << endl;

        switch (task_number)
        {
        case 1:
            task1();
            break;
        case 2:
            task2();
            break;
        case 3:
            task3();
            break;
        case 4:
            task4();
            break;
        case 5:
            task5();
            break;
        default:
            break;
        }

        cout << endl;
    }

}

void task1() {
    cout << "Задание 1" << endl;

    double x = 0, x_end = 0, x_step = 0, a = 0, b = 0, c = 0;

    cout << "Введите X начальное: ";
    cin >> x;
    cout << "Введите X конечное: ";
    cin >> x_end;
    cout << "Введите X шаг: ";
    cin >> x_step;
    cout << "Введите a: ";
    cin >> a;
    cout << "Введите b: ";
    cin >> b;
    cout << "Введите c: ";
    cin >> c;

    for (double F = 0; x <= x_end; x += x_step)
    {
        if (x < 5 && a != 0)
        {
            F = -a * (x * x) - b;
        }
        else if (x > 5 && a == 0)
        {
            F = (x - a) / x;
        }
        else
        {
            F = -x / b;
        }

        cout << "X = " << x << ", F = " << F << endl;
    }
}

void task2() {
    cout << "Задание 2" << endl;

    int n = 0;
    cout << "Введите целое число n: ";
    cin >> n;

    // Внешний цикл - сколько элементов нужно сложить
    double result = 0;
    for (int i = 1; i <= n; i++)
    {
        // Расчитываем сам факторил для этого элемента
        double fact = 0;
        for (int fact_index = 1; fact_index <= n; fact_index++)
        {
            fact += sin(fact_index);
        }

        // Добавляет результат расчёта очередного элемента к итоговой сумме
        result += (1 / fact);
    }

    cout << "Результат вычисления выражения: " << result << endl;
}

void task3() {
    cout << "Задание 3" << endl;

    double a = 0;
    int n = 0;

    cout << "Введите стартовое значение n: ";
    cin >> n;

    for (;a >= 0; n++) 
    {
        a = sin(tan(n));
    }

    cout << "Первый отрицательный член последовательности = " << a << ", при n =  " << n << endl;
}

void task4() {
    cout << "Задание 4" << endl;

    int n, div = 2;
    cout << "Введите число: ";
    cin >> n;

    cout << "Простые множители числа: 1";
   
    while (n > 1)
    {
        // Пока текущее число не станет кратно div
        while (n % div == 0)
        {
            cout << " * " << div;
            n = n / div;
        }

        div++;
    }

    cout << endl;
}

void task5() {
    cout << "Задание 5" << endl;

    double epsilon = 0, x = 0, result = 0, el = 1;

    cout << "Введите x (от 0 до 2): ";
    cin >> x;

    cout << "Введите точность (от 0 до 1): ";
    cin >> epsilon;

    int n = 0;
    for (; abs(el) >= epsilon; n++) {
        el = pow(-1, n) * pow(x, 2 * n + 1) / fact(2 * n + 1);
        result += el;

        cout << "Слогаемое №: " << n + 1 << ". Значение: " << abs(el) << endl;
    }

    cout << "Указанная точность очередного слогаемого достигнута!" << endl;
    cout << "Слогаемое №: " << n + 1 << ". Значение: " << abs(el) << ". Общяя сумма всех элементов выражения: " << result << endl;
    

    // АЛЬТЕРНАТИВНАЯ РЕАЛИЗАЦИЯ
    /*
    double e, x;
    cin >> x >> e;
    double a = x, sin = x;

    for (int n = 2; abs(a) >= e; n += 2) {
        a *= -x * x / n / (n + 1);
        sin += a;
        }

    cout << sin << "\n";
    }
    */
}

double fact(int N)
{
    if (N < 0)
        return 0; // возвращаем ноль
    if (N == 0)
        return 1; // возвращаем факториал от нуля - это 1
    else
        return N * fact(N - 1); // делаем рекурсию.
}