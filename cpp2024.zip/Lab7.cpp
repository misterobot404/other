#include <iostream>
#include <tchar.h>
#include <iostream>
#include <string>
#include <conio.h>
#include <array>
#include <vector>
#include <locale>
#include <fstream>
#include <streambuf>

using namespace std;

void CaesarIn(int k) {
    // Текстовые файлы находятся в cpp\x64\Debug как и сама программа
    // Запускаться программу только оттуда, если запускать через VS, то файлы не подхватываются
    ifstream input("input.txt");
    ofstream output("caesarin.txt");

    char buff;
    int iter;

    if (!input.is_open())
        cout << "Файл не может быть открыт!\n";
    else {
        while (!input.eof()) {
            buff = input.get();
            if (buff == ' ')
                output << ' ';
            if (buff == '\n')
                output << '\n';

            if (buff >= 'A' && buff <= 'Z') {
                buff += (k % 26);
                if (buff > 'Z')
                    buff -= 26;
                output << buff;
            }
            if (buff >= 'a' && buff <= 'z') {
                buff += (k % 26);
                if (buff > 'z')
                    buff -= 26;
                output << buff;

            }
            if (buff >= 'А' && buff <= 'Я') {
                buff += (k % 33);
                if (buff > 'Я')
                    buff -= 33;
                output << buff;
            }
            if (buff >= 'а' && buff <= 'я') {
                buff += (k % 33);
                if (buff > 'я')
                    buff -= 33;
                output << buff;
            }
        }
    }
    input.close();
    output.close();
}

void CaesarOut(int k) {
    ifstream input("caesarin.txt");
    ofstream output("caesarout.txt");

    char buff;
    int iter;

    if (!input.is_open())
        cout << "Файл не может быть открыт!\n";
    else {
        while (!input.eof()) {
            buff = input.get();
            if (buff == ' ')
                output << ' ';
            if (buff == '\n')
                output << '\n';

            if (buff >= 'A' && buff <= 'Z') {
                buff -= (k % 26);
                if (buff > 'Z')
                    buff += 26;
                output << buff;
            }
            if (buff >= 'a' && buff <= 'z') {
                buff -= (k % 26);
                if (buff > 'z')
                    buff += 26;
                output << buff;

            }
            if (buff >= 'А' && buff <= 'Я') {
                buff -= (k % 33);
                if (buff > 'Я')
                    buff += 33;
                output << buff;
            }
            if (buff >= 'а' && buff <= 'я') {
                buff -= (k % 33);
                if (buff > 'я')
                    buff += 33;
                output << buff;
            }
        }
    }
    input.close();
    output.close();
}

int main()
{
    // setlocale(LC_ALL, "Russian");
    cout << "**** Лабораторная работа №7 ****" << endl;
    cout << "Шифр Цезаря" << endl;

    int k = 0;
    cout << "Сдвиг: ";
    cin >> k;

    if (k < 1)
        return 0;

    cout << "Шифровка Цезарь. " << '\n';
    CaesarIn(k);
    cout << "Дешифровка Цезарь." << '\n';
    CaesarOut(k);

    system("pause");
    return 0;
}