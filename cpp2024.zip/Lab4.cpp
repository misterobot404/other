#include <iostream>

using namespace std;

void main() {
    // setlocale(LC_ALL, "Russian");
   
    cout << "**** Лабораторная работа №4 ****" << endl;

    int arr_lenght = 0, fill_type = 0;
    cout << "Введите размер массива: ";
    cin >> arr_lenght;
    // Создаём указатель на блок памяти под массив чисел
    int* ptr_arr = new int[arr_lenght]; 

    cout << endl << "Выберите способ заполнения массива" << endl;
    cout << "1. Cлучайные числа от -10 до 10" << endl;
    cout << "2. Ручной ввод" << endl;
    cout << "> ";
    cin >> fill_type;


    // Заполнение массива
    if (fill_type == 1)
    {
        // Инициализация генерации случайных чисел
        srand(time(0)); 

        // Генерируем целый случайный массив из arr_lenght эелментов от -10 до 10
        for (int i = 0; i < arr_lenght; i++)
        {
            ptr_arr[i] = -10 + rand() % 21;
        }
    }
    else if (fill_type == 2)
    {
        // Принимаем значения от пользователя
        for (int i = 0; i < arr_lenght; i++)
        {
            cout << "Введите " << i << " эллемент массива: ";
            cin >> ptr_arr[i];
        }
    }

    cout << "Массив: ";
    // Вывод массива на экран
    for (int i = 0; i < arr_lenght; i++)
    {
        cout << ptr_arr[i] << " ";
    }
    cout << endl;

    // Проверка на упорядовачивание
    string res_sort = "Массив упорядочен по убыванию";
    for (int i = 0; i < arr_lenght; i++)
    {
        if (ptr_arr[i] < ptr_arr[i + 1])
        {
            res_sort = "Массив не упорядочен по убыванию";
        }
    }
    cout << res_sort << endl;

    // Сумма отрицательных элементов
    double negative_sum = 0;
    for (int i = 0; i < arr_lenght; i++)
    {
        if (ptr_arr[i] < 0)
        {
            negative_sum += ptr_arr[i];
        }
    }
    cout << "Сумма отрицательных элементов: " << negative_sum << endl;

    // Произведение элементов массива, расположенных между максимальным и минимальным элементом
    int im = 0, jm = 0, max = ptr_arr[0], min = ptr_arr[0];
    for (int i = 0; i < arr_lenght; i++)
    {
        if (ptr_arr[i] > max)
        {
            max = ptr_arr[i];
            im = i;
        }
        if (ptr_arr[i] < min)
        {
            min = ptr_arr[i];
            jm = i;
        }
    }
    int proz = 1;
    if (im > jm)
    {
        for (int i = jm; i <= im; i++)
        {
            proz *= ptr_arr[i];
        }
    }
    else if (jm > im)
    {
        for (int i = jm; i <= im; i++)
        {
            proz *= ptr_arr[i];
        }
    }
    cout << "Произведение между максимальным и минимальным элементами = " << proz << endl;


    // Вывести локальные максимумы
    for (int i = 1; i < arr_lenght - 1; i++)
        if (ptr_arr[i] > ptr_arr[i - 1] && ptr_arr[i] > ptr_arr[i + 1])
            cout << "Локальный максимум под индексом: " << i << endl;


    // Отсортировать массив по убыванию методом выбора
    min = 0; // для записи минимального значения
    int buf = 0; // для обмена значениями 
    for (int i = 0; i < arr_lenght; i++)
    {
        min = i; // запомним номер текущей ячейки, как ячейки с минимальным значением
        // в цикле найдем реальный номер ячейки с минимальным значением
        for (int j = i + 1; j < arr_lenght; j++)
            min = (ptr_arr[j] < ptr_arr[min]) ? j : min;
        // cделаем перестановку этого элемента, поменяв его местами с текущим
        if (i != min)
        {
            buf = ptr_arr[i];
            ptr_arr[i] = ptr_arr[min];
            ptr_arr[min] = buf;
        }
    }
    cout << "Отсортированный массив по убиванию методом выбора: ";
    // Вывод массива на экран
    for (int i = 0; i < arr_lenght; i++)
    {
        cout << ptr_arr[i] << " ";
    }
    cout << endl;

    cout << endl;
    system("pause");
    delete[]ptr_arr; // освобождаем занимаемую память
}