#include <iostream>

using namespace std;

void task1();
void task2();
void task3();

void main() {
    // setlocale(LC_ALL, "Russian");

    while (true)
    {
        cout << "**** Лабораторная работа №1 ****" << endl;
        cout << "Введите номер задания (1, 2, 3): ";
        int task_number = NULL;
        cin >> task_number;
        cout << endl;

        switch (task_number)
        {
        case 1:
            task1();
            break;
        case 2:
            task2();
            break;
        case 3:
            task3();
            break;
        default:
            break;
        }

        cout << endl;
    }
   
}

void task1() {
    cout << "Задание 1" << endl;

    double lenght_in_meters = 0, speed_in_minuts = 0;

    cout << "Введите пройденный путь (в метрах): ";
    cin >> lenght_in_meters;

    cout << "Введите время прохождения пути (в минутах): ";
    cin >> speed_in_minuts;

    // Расчитываем в м/c
    double speed_in_second = speed_in_minuts * 60;
    cout << "Скорость в метрах в секунду: " << lenght_in_meters / speed_in_second  << endl;

    // Расчитываем в км/ч
    double lenght_in_km = lenght_in_meters / 1000;
    double speed_in_hours = speed_in_minuts / 60;
    cout << "Скорость в киллометров в час: " << lenght_in_km / speed_in_hours << endl;
}

void task2() {
    cout << "Задание 2" << endl;

    /*
    Площадь равнобедренного треугольника равна половине произведения основания на высоту, опущенную на него.

    Из условия нам известна боковая сторона - 10 см, а так же длина основание 16 см. Нам нужно найти высоту. 
    Высота в равнобедренном треугольника так же является медианой (делить основание на две равные части).
    Рассмотрим высоту как катет прямоугольного треугольника, образованного боковой стороной (гипотенуза) и половиной основания: 16 : 2 = 8 см.
    Тогда через теорему Пифагора можно получить высоту равномедренного треугольника.
    c^2 = a^2 + b^2;
    a = √(c^2 - b^2) = √(10^2 - 8^2) = √(100 - 64) = √36 = 6 см.
    a - высота равнобедренного треугольника

    Вычислим площадь:
    S = 1/2 * 16 * 6 = 48 см^2.
    */

    double a = 0, b = 0;

    cout << "Введите длину основания равнобедренного треугольника: ";
    cin >> a;

    cout << "Введите длину боковой стороны равнобедренного треугольника : ";
    cin >> b;

    double c = a / 2;
    double h = sqrt(b * b - c * c);

    cout << "Площадь равнобедренного треугольника: " << a * h * 0.5 << endl;
}

void task3() {
    cout << "Задание 3" << endl;

    double a = 0, b = 0, c = 0;

    cout << "Введите значение A: ";
    cin >> a;

    cout << "Введите значение B: ";
    cin >> b;

    cout << "Введите значение C: ";
    cin >> c;

    // Проверяем существуют ли вещественные корни у квадратного уровнения A∗(x*x)+B∗x+C=0 через дискриминант D
    // D = b*b — 4ac
    if ((b * b - 4 * a * c) >= 0)
    {
        // Вещественные квадратные корни имеются
        cout << "True" << endl;
    }
    else
    {
        // Вещественные квадратные корни не имеются
        cout << "False" << endl;
    }
}