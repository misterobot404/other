#include <iostream>
#include <iomanip>

using namespace std;

int overlap(float*, float*, int);


void main() {
    // setlocale(LC_ALL, "Russian");

    cout << "**** Лабораторная работа №5 ****" << endl;
        
    int arr_lenght_rows = 0, arr_lenght_columns = 0, fill_type = 0;
    cout << "Введите размер массива" << endl;
    cout << "Введите количество строк: ";
    cin >> arr_lenght_rows;
    cout << "Введите количество столбцов: ";
    cin >> arr_lenght_columns;
        
    // Создаём указатель на блок памяти под двумерный массив
    float** ptr_matrix = new float* [arr_lenght_rows]; // Строки
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
        ptr_matrix[row_index] = new float[arr_lenght_columns]; // Столбы

    cout << endl << "Выберите способ заполнения массива" << endl;
    cout << "1. Cлучайные числа от -10 до 10" << endl;
    cout << "2. Ручной ввод" << endl;
    cout << "> ";
    cin >> fill_type;


    // Заполнение массива
    if (fill_type == 1)
    {
        // Инициализация генерации случайных чисел
        srand(time(0));

        // Генерируем целый случайный массив из arr_lenght эелментов от -10 до 10
        for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
        {
            for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
            {
                ptr_matrix[row_index][col_index] = -10 + rand() % 21;
            }
        }
    }
    else if (fill_type == 2)
    {
        // Принимаем значения от пользователя
        for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
        {
            for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
            {
                cout << "Введите [" << row_index << "][" << col_index << "] эллемент массива: ";
                cin >> ptr_matrix[row_index][col_index];
            }
            cout << endl;
        }
    }

    cout << "Двумерный массив (матрица): " << endl;
    // Вывод массива на экран
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
        {
            cout << setw(4) << setprecision(2) << ptr_matrix[row_index][col_index] << "   ";
        }
        cout << endl;
    }


    // Найти суммы элементов у четных строк
    cout << "Сумма элементов у четных строк" << endl;
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        // Проверка на чётность
        if (row_index % 2 == 0)
        {
            int sum_elements_even_rows = 0;
            for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
            {
                sum_elements_even_rows += ptr_matrix[row_index][col_index];
            }

            cout << "Сумма элементов в строке с индексом " << row_index << ": " << sum_elements_even_rows << endl;
        }
    }

    // Найти количество строк, похожих на первую строку (у которых совпадают множества)
    int count_same_rows = 0;
    for (int row_index = 1; row_index < arr_lenght_rows; row_index++)
    {
        if (overlap(ptr_matrix[row_index], ptr_matrix[0], arr_lenght_columns) && overlap(ptr_matrix[0], ptr_matrix[row_index], arr_lenght_columns)) {
            count_same_rows++;
        }
    }
    cout << "Количество строк похожих на первую строку: " << count_same_rows << endl;


    // Удалить первый столбец, содержащий только положительные элементы
    // Сначала нужно найти индекс этого столбца (-1 значит ничего не нужно удалять, иначе будет индекс от 0)
    int need_remove_column_index = -1;
    for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
    {
        bool all_positive_in_this_column = true;

        for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
        {
            if (ptr_matrix[row_index][col_index] <= 0)
            {
                all_positive_in_this_column = false;
            }
        }

        if (all_positive_in_this_column)
        {
            need_remove_column_index = col_index;
            break;
        }
    }

    if (need_remove_column_index != -1)
    {
        cout << "Столбец с положительными элементами имеет индекс: " << need_remove_column_index << ". Удаление..." << endl;
       
        // Далее нужно создать новый двумерный массив и переписать туда элементы из изначального двумерного массива пропуская найденную колонку
        float** new_ptr_matrix = new float* [arr_lenght_rows]; // Строки
        for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
        {
            new_ptr_matrix[row_index] = new float[arr_lenght_columns - 1]; // Столбы

            for (int col_index = 0; col_index < arr_lenght_columns - 1; col_index++)
            {
                if (col_index >= need_remove_column_index)
                {
                   new_ptr_matrix[row_index][col_index] = ptr_matrix[row_index][col_index + 1]; 
                }
                else
                {
                   new_ptr_matrix[row_index][col_index] = ptr_matrix[row_index][col_index];
                }
            }
        }

        arr_lenght_columns -= 1;
        ptr_matrix = new_ptr_matrix;
    }
    else
    {
        cout << "Столбец с положительными элементами не найден" << endl;
    }


    // Вывод обновленного массива на экран
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
        {
            cout << setw(4) << setprecision(2) << ptr_matrix[row_index][col_index] << "   ";
        }
        cout << endl;
    }

    // Вывод среднестатистического элемента массива
    double average_best_value = ptr_matrix[0][0];
    double all_sum = 0;
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
        {
            all_sum += ptr_matrix[row_index][col_index];
        }
    }
    double average_all_value = all_sum / (arr_lenght_rows * arr_lenght_columns);
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        for (int col_index = 0; col_index < arr_lenght_columns; col_index++)
        {
            if ((abs(average_all_value - ptr_matrix[row_index][col_index]) < abs(average_all_value - average_best_value)))
            {
                average_best_value = ptr_matrix[row_index][col_index];
            }
        }
    }
    cout << "Среднее арифметическое элементов массива: " << average_all_value << endl;
    cout << "Среднестатистический элемент массива: " << average_best_value << endl;


    // Очистка двумерного массива перед закрытием программы
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        delete[] ptr_matrix[row_index];
    }
        
    system("pause");
}

int overlap(float* a, float* b, int size) //если все элементы строки а содержатся в строке b возвращает 1,иначе 0
{
    int i, j, flag = 0;
    for (i = 0; i < size; i++, flag = 0) {
        for (j = 0; j < size; j++) {
            if (*(a + i) == *(b + j)) {
                flag = 1;
                break;
            }
        }
        if (!flag)
            return 0;
    }
    return 1;
}