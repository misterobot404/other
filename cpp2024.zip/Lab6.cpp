#include <iostream>
#include <iomanip>

using namespace std;

static void showTable(string** ptr_table, int arr_lenght_rows, int arr_lenght_columns) {
    
    cout << "Название"
        << setw(15) << "Группа"
        << setw(30) << "Место обитания"
        << setw(45) << "Численность популяции"
        << endl;
    for (int row_index = 0; row_index < arr_lenght_rows; row_index++)
    {
        for (int col_index = 0, margin = 0; col_index < arr_lenght_columns; col_index++, margin += 10)
        {
            cout << setw(margin) << ptr_table[row_index][col_index];
        }
        cout << endl;
    }
}

static void addRow() {
    
}

static void removeRowByIndex() {
   
}

void main() {
    // setlocale(LC_ALL, "Russian");

    while (true)
    {
        cout << "**** Лабораторная работа №6 ****" << endl;

        // Создаём таблицу
        int row_lenght = 3;
        int col_lenght = 4;
        string** ptr_table = new string * [row_lenght]; // Строки
        for (int row_index = 0; row_index < row_lenght; row_index++)
            ptr_table[row_index] = new string[col_lenght]; // 

        // Начальное заполнение таблицы
        ptr_table[0][0] = "Джейран";
        ptr_table[0][1] = "A";
        ptr_table[0][2] = "Азиа";
        ptr_table[0][3] = "30000";

        ptr_table[1][0] = "Гну";
        ptr_table[1][1] = "B";
        ptr_table[1][2] = "Африка";
        ptr_table[1][3] = "560000";

        ptr_table[1][0] = "Бейза";
        ptr_table[1][1] = "H";
        ptr_table[1][2] = "Африка";
        ptr_table[1][3] = "2500";
       
           

        cout << "Выберите действия: " << endl;
        cout << "1. Вывести таблицу " << endl;
        cout << "2. Добавить строку? " << endl;
        cout << "3. Удалить строку? " << endl;
        cout << "> ";
        int task_number = NULL;
        cin >> task_number;
        cout << endl;

        switch (task_number)
        {
            case 1:
                showTable(ptr_table, row_lenght, col_lenght);
                break;
            case 2:
                addRow();
                break;
            case 3:
                removeRowByIndex();
                break;
            default:
                break;
        }

        cout << endl;
    }

}